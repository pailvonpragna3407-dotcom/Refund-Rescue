# Architecture

## Demo implemented
Browser UI (HTML/CSS/JavaScript)
→ synthetic case records embedded in the page
→ deterministic evidence-gap and status checks
→ next-step recommendation
→ editable complaint draft

## Proposed production architecture
Customer / Support UI (React + Tailwind)
→ Java Spring Boot REST API
→ PostgreSQL case and event store
→ evidence-processing service with sensitive-field masking
→ rule engine for status/reference/evidence mismatches
→ optional LLM for summarization and draft wording using minimized data
→ authorized payment-provider APIs/webhooks where available
→ audit log and role-based access control

## Data trust model
1. Customer-provided: uploaded receipt or bank-statement excerpt; treat as user evidence, not authoritative payment confirmation.
2. Merchant-reported: order status and refund initiation details; treat as a claim from the merchant system.
3. Verified: payment-provider or bank data obtained from an authorized, authenticated integration; record source and timestamp.

## Security and privacy
- Minimize data collection.
- Mask account numbers, names, and unrelated transaction data before optional AI analysis.
- Use role-based access, audit logs, encrypted transport and storage in a real deployment.
- Never treat LLM output as authoritative financial verification.
- Keep human review before a complaint is sent.
- Use synthetic data for public demos.

## Limitations
The bundled prototype is local-only. It has no backend, persistent database, real AI model, live payment integration, or LinuxONE deployment.
