# Refund Rescue — Submission Pack

## Included
- `Refund_Rescue_Abstract.pdf` — abstract document.
- `Refund_Rescue_Pitch_Deck.pptx` — editable pitch deck.
- `refund-rescue-demo/index.html` — refreshed responsive dashboard prototype.
- `README.md` — setup and demo instructions.
- `SHORT_PROJECT_DESCRIPTION.txt` — short portal description.
- `DEMO_SCRIPT_3_MINUTES.txt` — suggested demo narration.
- `ARCHITECTURE.md` — architecture and privacy notes.

## Run the demo
1. Extract the ZIP.
2. Open `refund-rescue-demo/index.html` in a modern browser.
3. Search/filter cases, open a case, inspect the Proof Chain/journey, run demo analysis, and generate/copy a complaint draft.
4. The dashboard is responsive for desktop and mobile.

## Important accuracy note
This is a front-end prototype using synthetic data and transparent rule-based checks. It is not connected to a real bank, merchant, payment gateway, live AI model, or persistent backend. The proposed production architecture uses React/Tailwind, Java Spring Boot, PostgreSQL, optional masked LLM analysis, and authorized payment-provider APIs/webhooks.

## IBM Z / LinuxONE
The deck describes how a production backend could be deployed on IBM LinuxONE. This package does not itself establish that the prototype has been deployed to LinuxONE.
